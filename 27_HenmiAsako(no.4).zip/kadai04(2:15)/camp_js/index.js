$(document).ready(function(){
    $('#ex').fadeIn(4000);
});

$(document).ready(function(){
    $('p').css('background', '#000');
    $('p').css('color', '#fff');
    $('#ex p:nth-child(even)').css('background', '#fff');
});


